# TTM4185
### Velkommen til øving 3 i Sikkerhet og Robusthet i IKT systemer.

I denne øvingen vil du måtte kjøre jupyter notebooks for å løse oppgavene.
For å installere notebooks trenger du python3.
Øvingen er testet med python 3.6.5 og 3.7.0 men alle python3 versjoner>=3.5 fungerer.\
Det er nødvendig med python og pip.
 * Install python: https://www.python.org/downloads/
 * Install pip: https://pip.pypa.io/en/stable/installing/
 * Install requirements: pip install -r requirements.txt

For å åpne jupyter notebooks:
 * Åpne terminal i øving3 mappen
 * Kjør kommando: python -m notebook

Det er så bare å åpne Oving3.ipnb. 
####Lykke til!